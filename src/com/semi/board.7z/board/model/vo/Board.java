package com.semi.board.model.vo;

import java.sql.Date;

public class Board {

	private String boardNo;
	private String boardTitle;
	private String boardCategory;
	private String boardContent;
	private Date createDate;
	private int count;
	private String writerNo;
	private String status;
	
	public Board() {
		
	}

	public Board(String boardNo, String boardTitle, String boardCategory, String boardContent, Date createDate,
			int count, String writerNo, String status) {
		super();
		this.boardNo = boardNo;
		this.boardTitle = boardTitle;
		this.boardCategory = boardCategory;
		this.boardContent = boardContent;
		this.createDate = createDate;
		this.count = count;
		this.writerNo = writerNo;
		this.status = status;
	}

	public String getBoardNo() {
		return boardNo;
	}

	public void setBoardNo(String boardNo) {
		this.boardNo = boardNo;
	}

	public String getBoardTitle() {
		return boardTitle;
	}

	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}

	public String getBoardCategory() {
		return boardCategory;
	}

	public void setBoardCategory(String boardCategory) {
		this.boardCategory = boardCategory;
	}

	public String getBoardContent() {
		return boardContent;
	}

	public void setBoardContent(String boardContent) {
		this.boardContent = boardContent;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getWriterNo() {
		return writerNo;
	}

	public void setWriterNo(String writerNo) {
		this.writerNo = writerNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Board [boardNo=" + boardNo + ", boardTitle=" + boardTitle + ", boardCategory=" + boardCategory
				+ ", boardContent=" + boardContent + ", createDate=" + createDate + ", count=" + count + ", writerNo="
				+ writerNo + ", status=" + status + "]";
	}
	
	
}
