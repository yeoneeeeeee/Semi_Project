package com.semi.board.model.vo;

public class Reply {

}
